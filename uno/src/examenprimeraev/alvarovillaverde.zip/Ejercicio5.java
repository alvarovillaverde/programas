package examenprimeraev;

import java.util.Scanner;

public class Ejercicio5 {

    public static int sumaDigitos(int n) {
        int suma = 0; //inicializo la suma

        if (n == 0) {
            int digito = n%10; //saco el digito
            suma += digito; //sumo el digito a la suma
            return suma; //devuelvo la suma
        } else {
            return sumaDigitos(n);
        }
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        //Pido el numero por teclado
        System.out.println("Dame un numero:");
        int n = Integer.parseInt(sc.nextLine());

        System.out.println(sumaDigitos(n));

        sc.close();
    }
}
